package com.kh.example.gearrent;

public class Run {

	public static void main(String[] args) {
		new GearRentMenu().mainMenu();

	}

}
